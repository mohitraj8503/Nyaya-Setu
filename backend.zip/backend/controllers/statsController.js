const Submission = require('../models/Submission');
const Contact = require('../models/Contact');
const Newsletter = require('../models/Newsletter');
const Tracker = require('../models/Tracker');

// @desc    Get live metrics and statistics of runtime collected data
// @route   GET /api/stats
exports.getStats = async (req, res) => {
  try {
    const [
      totalSubmissions,
      totalContacts,
      totalSubscribers,
      submissionsByCategory,
      recentSubmissions,
      recentContacts,
      recentSubscribers
    ] = await Promise.all([
      Submission.countDocuments(),
      Contact.countDocuments(),
      Newsletter.countDocuments(),
      Submission.aggregate([
        { $group: { _id: '$category', count: { $sum: 1 } } },
        { $sort: { count: -1 } }
      ]),
      Submission.find().sort({ createdAt: -1 }).limit(10),
      Contact.find().sort({ createdAt: -1 }).limit(10),
      Newsletter.find().sort({ createdAt: -1 }).limit(10),
    ]);

    res.status(200).json({
      success: true,
      data: {
        summary: {
          totalSubmissions,
          totalContacts,
          totalSubscribers,
          totalResolved: await Submission.countDocuments({ status: 'Resolved' }),
          systemStatus: 'Online (MongoDB Connected)',
        },
        categoryBreakdown: submissionsByCategory,
        recentSubmissions,
        recentContacts,
        recentSubscribers,
      },
    });
  } catch (error) {
    console.error('Error computing stats:', error);
    res.status(500).json({
      success: false,
      message: 'Server error retrieving statistics',
      error: error.message,
    });
  }
};
