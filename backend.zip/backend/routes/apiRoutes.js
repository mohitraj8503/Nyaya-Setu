const express = require('express');
const router = express.Router();

const contactController = require('../controllers/contactController');
const submissionController = require('../controllers/submissionController');
const newsletterController = require('../controllers/newsletterController');
const trackerController = require('../controllers/trackerController');
const statsController = require('../controllers/statsController');

// Contact routes
router.post('/contact', contactController.createContact);
router.get('/contact', contactController.getContacts);
router.patch('/contact/:id', contactController.updateContactStatus);

// Grievance / Citizen submission routes
router.post('/submissions', submissionController.createSubmission);
router.get('/submissions', submissionController.getSubmissions);
router.get('/submissions/:trackingCode', submissionController.getSubmissionByCode);
router.patch('/submissions/:trackingCode', submissionController.updateSubmission);

// Newsletter subscription routes
router.post('/newsletter', newsletterController.subscribe);
router.get('/newsletter', newsletterController.getSubscribers);

// Tracker routes
router.get('/tracker/:trackingCode', trackerController.getTracker);
router.post('/tracker/:trackingCode/milestone', trackerController.addMilestone);

// Stats & Health
router.get('/stats', statsController.getStats);
router.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    db: require('mongoose').connection.readyState === 1 ? 'connected' : 'disconnected',
  });
});

module.exports = router;
